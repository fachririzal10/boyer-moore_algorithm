def boyer_moore(text, pattern):
    n = len(text)
    m = len(pattern)
    if m == 0:
        return 0
    last = {}
    for i in range(n):
        last[text[i]] = -1
    for i in range(m):
        last[pattern[i]] = i
    i = m - 1
    k = m - 1
    while i < n:
        if text[i] == pattern[k]:
            if k == 0:
                return i
            i -= 1
            k -= 1
        else:
            j = last[text[i]]
            i += m - min(k, j + 1)
            k = m - 1
    return -1

# contoh penggunaan
text = "saya sedang belajar algoritma dan struktur data"
pattern = "struktur data"
print(boyer_moore(text, pattern))
